#include "quadric_aux_structures.h"

namespace QEM
{

void computeTrianglesPlane(vector<dvect > &trPl, Simplicial_Mesh &mesh)
{
    double coords[3][3];

//    dvect tmp = { -0.2003, -0.364941, -0.05726 };
//    Vertex<COORDBASETYPE> v1 = Vertex<COORDBASETYPE>(tmp,tmp[2]);
//    tmp = { -0.188822, -0.357264, -0.061155 };
//    Vertex<COORDBASETYPE> v2 = Vertex<COORDBASETYPE>(tmp,tmp[2]);
//    tmp = { -0.199747, -0.350492, -0.048369 };
//    Vertex<COORDBASETYPE> v3 = Vertex<COORDBASETYPE>(tmp,tmp[2]);

    for(int i=1; i<=mesh.get_top_cells_num(1); i++)
    {
        Top_Simplex &tri = mesh.get_top_cell(1,i);
//        vector<bool> test = { false, false, false };

        for(int v=0; v<tri.get_vertices_num(); v++)
        {
            Vertex<COORDBASETYPE> &vert = mesh.get_vertex(tri.TV(v));
//            cout<<vert<<endl;

            coords[0][v] = vert.getC(0);
            coords[1][v] = vert.getC(1);
            coords[2][v] = vert.getC(2);

//            if(v1 == vert || v2 == vert || v3 == vert)
//            {
////                cout<<"vertici uguali"<<endl;
//                test[v] = true;
////                int aed; cin>>aed;
//            }
        }

        double a,b,c,m;

        a = (coords[1][1] - coords[1][0]) * (coords[2][2] - coords[2][0]) - (coords[2][1] - coords[2][0]) * (coords[1][2] - coords[1][0]);

        b = (coords[2][1] - coords[2][0]) * (coords[0][2] - coords[0][0]) - (coords[0][1] - coords[0][0]) * (coords[2][2] - coords[2][0]);

        c = (coords[0][1] - coords[0][0]) * (coords[1][2] - coords[1][0]) - (coords[1][1] - coords[1][0]) * (coords[0][2] - coords[0][0]);

        m = sqrt(a*a + b*b + c*c);
        a = a/m;
        b = b/m;
        c = c/m;

        trPl[i-1][0]=a;
        trPl[i-1][1]=b;
        trPl[i-1][2]=c;
        trPl[i-1][3]= -1*(a*coords[0][0] + b*coords[1][0] + c*coords[2][0]);

//        cout<<trPl[i-1][0]<<" "<<trPl[i-1][1]<<" "<<trPl[i-1][2]<<" "<<trPl[i-1][3]<<endl;
////        int x; cin>>x;
//        if(test[0] && test[1] && test[2])
//        {
//            cout<<"triangolo trovato"<<endl;
//            int x; cin>>x;
//        }
    }
}

void computeInitialQEM(vector<Matrix4x4> &vQEM, vector<dvect > &planes, Simplicial_Mesh &mesh)
{
    /* compute initial quadric */
    for(int i=1; i<=mesh.get_top_cells_num(1); i++)
    {
        Top_Simplex &tri = mesh.get_top_cell(1,i);

        /* faces are triangles */
        for (int j = 0; j < tri.get_vertices_num(); j++)
        {
            double a = planes[i-1][0];
            vQEM[ tri.TV(j) -1 ] += Matrix4x4(a);
        }
    }

}

double compute_error(int v1, int v2, vector<Matrix4x4> &vQEM, Simplicial_Mesh &mesh)
{
    double min_error;
    Matrix4x4 q_bar;
//    Matrix4x4 q_delta;

    double new_vertex[3];
//    assert(new_vertex != NULL);

    /* computer quadric of virtual vertex vf */
    q_bar = vQEM[v1 -1] + vQEM[v2 -1];

//    /* test if q_bar is symmetric */
//    if (q_bar[1] != q_bar[4] || q_bar[2] != q_bar[8] || q_bar[6] != q_bar[9] ||
//        q_bar[3] != q_bar[12] || q_bar[7] != q_bar[13] || q_bar[11] != q_bar[14])
//    {
//        cout << "OKKIO NON E' SIMMETRICA" << endl;
//    }

//    q_delta = Matrix4x4( q_bar[0], q_bar[1],  q_bar[2],  q_bar[3],
//            q_bar[4], q_bar[5],  q_bar[6],  q_bar[7],
//            q_bar[8], q_bar[9], q_bar[10], q_bar[11],
//            0,        0,	      0,        1);

    Vertex<COORDBASETYPE> vert1 = mesh.get_vertex(v1);
    Vertex<COORDBASETYPE> vert2 = mesh.get_vertex(v2);

    double vx1 = vert1.getC(0);
    double vy1 = vert1.getC(1);
    double vz1 = vert1.getC(2);

    double vx2 = vert2.getC(0);
    double vy2 = vert2.getC(1);
    double vz2 = vert2.getC(2);

    /* if q_delta is invertible */
//    if ( double det = q_delta.det(0, 1, 2, 4, 5, 6, 8, 9, 10) )		/* note that det(q_delta) equals to M44 */
//    {
//        (*new_vertex)[0] = -1/det*(q_delta.det(1, 2, 3, 5, 6, 7, 9, 10, 11));	/* vx = A41/det(q_delta) */
//        (*new_vertex)[1] =  1/det*(q_delta.det(0, 2, 3, 4, 6, 7, 8, 10, 11));	/* vy = A42/det(q_delta) */
//        (*new_vertex)[2] = -1/det*(q_delta.det(0, 1, 3, 4, 5, 7, 8, 9, 11));		/* vz = A43/det(q_delta) */
//    }

    /*
     * if q_delta is NOT invertible, select
     * vertex from v1, v2, and (v1+v2)/2
     */
//    else{

    double vx3 = double (vx1+vx2)/2.0;
    double vy3 = double (vy1+vy2)/2.0;
    double vz3 = double (vz1+vz2)/2.0;

    double error1 = vertex_error(q_bar, vx1, vy1, vz1);
    double error2 = vertex_error(q_bar, vx2, vy2, vz2);
    double error3 = vertex_error(q_bar, vx3, vy3, vz3);

    min_error = std::min(error1, std::min(error2, error3));
    if (error1 == min_error) { new_vertex[0] = vx1; new_vertex[1] = vy1, new_vertex[2] = vz1; }
    else if (error2 == min_error) { new_vertex[0] = vx2; new_vertex[1] = vy2, new_vertex[2] = vz2; }
    else{ new_vertex[0] = vx3; new_vertex[1] = vy3, new_vertex[2] = vz3; }

//    }

//    printf("new vertex \n");
//    printf("%lf %lf %lf\n", vx1, vy1, vz1);
//    printf("%lf %lf %lf\n", vx2, vy2, vz2);
//    //printf("%lf %lf %lf\n", vx3, vy3, vz3);
//    printf("%lf %lf %lf\n", (*new_vertex)[0], (*new_vertex)[1], (*new_vertex)[2]);


    min_error = vertex_error(q_bar, new_vertex[0], new_vertex[1], new_vertex[2]);

    return min_error;
}

double vertex_error(Matrix4x4 q, double x, double y, double z)
{
    return q[0]*x*x + 2*q[1]*x*y + 2*q[2]*x*z + 2*q[3]*x + q[5]*y*y
        + 2*q[6]*y*z + 2*q[7]*y + q[10]*z*z + 2*q[11]*z + q[15];
}

}
